# Microsoft Operations Management Suite (OMS) Container Monitoring Example

This example is deprecated, for up to date instructions, please visit [https://github.com/Microsoft/OMS-docker/tree/master/Kubernetes](https://github.com/Microsoft/OMS-docker/tree/master/Kubernetes).
